from .CommentAnalyzer import CommentAnalyzer

__version__ = "1.0.2"
__all__ = ['CommentAnalyzer']
